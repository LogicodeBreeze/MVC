2024-05-20 09:15:32#192.168.1.45#admin#admin123#Contraseña incorrecta
2024-05-20 09:15:40#192.168.1.45#admin#123456#Contraseña incorrecta
2024-05-20 10:05:12#85.42.12.210#user_test#qwerty#Usuario no encontrado
2024-05-20 11:20:00#127.0.0.1#root#root#Contraseña incorrecta
2024-05-20 12:45:10#10.0.0.5#juan@email.com#password#Contraseña incorrecta