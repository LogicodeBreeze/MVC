-- Creación de la base de datos
CREATE DATABASE IF NOT EXISTS Anuncios CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE Anuncios;


-- 1. Tabla de Usuarios
-- Almacena a los vendedores de la plataforma con su nivel de acceso
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL, 
    nivel INT DEFAULT 2,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Tabla de Artículos
-- Almacena los anuncios vinculados a un usuario
CREATE TABLE articulos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    descripcion TEXT NOT NULL,
    precio DECIMAL(10, 2) NOT NULL,
    usuario_id INT NOT NULL,
    fecha_publicacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    -- Relación: Si se borra un usuario, se borran sus anuncios (ON DELETE CASCADE)
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Datos de prueba para el examen
-- Observa que no especificamos el nivel en el INSERT para que tome el valor 2 por defecto
INSERT INTO usuarios (nombre, email, password) VALUES 
('Ana Profesora', 'ana@ejemplo.com', '123456'), 
('Juan Alumno', 'juan@ejemplo.com', '123456');

-- Ejemplo de un usuario con nivel diferente (ej. Administrador nivel 1)
INSERT INTO usuarios (nombre, email, password, nivel) VALUES 
('Admin', 'admin@anuncios.com', '123456', 3);

INSERT INTO articulos (titulo, descripcion, precio, usuario_id) VALUES 
('Bicicleta de montaña', 'En perfecto estado, poco uso.', 150.00, 1),
('Monitor 24 pulgadas', 'Resolución 4K, ideal para programar.', 120.50, 1),
('Teclado Mecánico', 'RGB, interruptores Blue.', 45.00, 2);