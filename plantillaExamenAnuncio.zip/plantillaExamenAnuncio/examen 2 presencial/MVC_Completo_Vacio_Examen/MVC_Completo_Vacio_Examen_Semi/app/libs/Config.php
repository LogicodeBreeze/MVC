<?php
define('DB_HOST', 'localhost');
//Aqui ponemos la BD de nuestro proyecto
define('DB_NAME', 'Anuncios');
define('DB_USER', 'root');
define('DB_PASS', '');


$mvc_vis_css = "estilo.css";

?>