<?php
class InicioController extends Controller{
   
   
    public function inicio()
    {

        $params = array(
            'mensaje' => 'Bienvenido',
            'mensaje2' => 'Utiliza este esqueleto para realizar el examen',
            'fecha' => date('d-m-Y')
        );
        

        require __DIR__ . '/../templates/inicio.php';
    }

    public function verAnuncios()

    {
        $params = [];

        $modeloAnuncio=new Anuncio();
        $anuncios=$modeloAnuncio->obtenerAnuncios();
        
        $params = [
            'articulos' => $anuncios
        ];

        // var_dump($anuncios);
        // exit;




        require __DIR__ . '/../templates/verAnuncios.php';
    }

    
    public function insertarAnuncio()

    {
        $params=[];
        $errores=[];

        if($_POST){

            $titulo = recoge("titulo");
            $descripcion=recoge("descripcion");
            $precio=recoge("precio");


            if (!cTexto($titulo,"titulo",$errores,30,1)){
                $params['mensaje'] = 'titulo no valido';
            }
            if (!cTexto($descripcion,"descripcion",$errores,30,1)){
                $params['mensaje'] = 'descripcion no valido';
            
             }

            if (!cNum($precio,"precio",$errores)){
                $params['mensaje'] = 'precio no valido';
            }

            if(empty($errores)){
                
                $modeloAnuncios=new Anuncio();
                if(
                    $modeloAnuncios->crearAnuncios(
                    $titulo,$descripcion,$precio,$this->session->getUserId()
                )
                ) {
                    header("Location: index.php?ctl=verAnuncios");
                    exit;
                } else {
                    $params['mensaje'] = 'error al insertar anuncio';
                }
                
                

            }
        }

        require __DIR__ . '/../templates/formAltaAnuncio.php';
    

    }

    public function eliminarAnuncio(){
        
        if ($_POST) {

            $id = recoge("id");

            $modeloAnuncio= new Anuncio();
            
            if($modeloAnuncio->eliminarAnuncio($id)) {
                header("Location: index.php?ctl=verAnuncios");
                exit;
            }

        }    
    }
    
    public function actualizarAnuncio(){

        if ($_POST) {

            $id = recoge("id");

            $modeloAnuncio= new Anuncio();
            
            $anuncio = $modeloAnuncio->obtener($id);

            // Si no existe el anuncio, te manda a la misma pagina
            if (!$anuncio) {
                header("Location: index.php?ctl=verAnuncios");
                exit;
            }

            $params = [
                'titulo' => $anuncio['titulo'],
                'descripcion' => $anuncio['descripcion'],
                'precio' => $anuncio['precio']
            ];

            $modeloAnuncio->actualizarAnuncio($id);
            header('Location:index.php?ctl=actualizarAnuncio');
        exit;
            require __DIR__ . '/../templates/formEditarAnuncio.php';

        }    
    }

   
}
