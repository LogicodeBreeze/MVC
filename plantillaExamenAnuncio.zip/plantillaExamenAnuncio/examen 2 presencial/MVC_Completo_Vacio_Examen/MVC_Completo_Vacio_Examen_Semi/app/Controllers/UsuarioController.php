<?php
class UsuarioController extends Controller{
    private $pdo;

    public function __construct(SessionManager $session) {
        parent::__construct($session);
        $this->pdo = Database::getConnection();
    }
//usuario no logeado
    public function iniciarSesion(){
        
        $params = [];
        $errores = [];

        // Esta parte se ejecuta cuando envias el formulario
        if($_POST) {

            $nombreUsuario= recoge("nombreUsuario");
            $contrasenya= recoge("contrasenya");

            if (!cTexto($nombreUsuario,"nombreUsuario",$errores,30,1)) {
                $params['mensaje']= "Usuario no valido";
            }
        
            if(empty($errores)){
                
                $modeloUsuario= new Usuario();
                $usuario = $modeloUsuario->iniciarSesion($nombreUsuario);

                if ($usuario && $usuario['password'] == $contrasenya) {

                    $this->session->login(
                        $usuario['id'],
                        $usuario['nombre'],
                        $usuario['nivel']
                    );

                    header('Location: index.php?ctl=verAnuncios');
                    exit;

                }

            }
    
        }



        // Esto muestra la plantilla
        require __DIR__ . '/../templates/formInicioSesion.php';
    }

}