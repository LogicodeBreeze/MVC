<?php ob_start() ?>

    <div class="container text-center p-4">
        <div class="col-md-12" id="cabecera">
            <h1 class="h1Inicio">NUEVO ANUNCIO</h1>
        </div>
    </div>

    <div class="container text-center py-2">
        <div class="col-md-12">
            <?php if(isset($params['mensaje'])) :?>
                <b><span style="color: rgba(200, 119, 119, 1);"><?php echo $params['mensaje'] ?></span></b>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="container text-center p-4">
        <form ACTION="index.php?ctl=insertarAnuncio" METHOD="post" NAME="formInsertarAnuncio">
            <h5><b>Publicar un artículo en venta</b></h5>
            
            <p>
                <input TYPE="text" NAME="titulo" PLACEHOLDER="Título del artículo" value="<?php echo $params['titulo'] ?? '' ?>" style="width: 300px;"><br>
            </p>
            
            <p>
                <textarea NAME="descripcion" PLACEHOLDER="Descripción detallada" rows="4" style="width: 300px;"><?php echo $params['descripcion'] ?? '' ?></textarea><br>
            </p>
            
            <p>
                <input TYPE="number" step="0.01" NAME="precio" PLACEHOLDER="Precio (€)" value="<?php echo $params['precio'] ?? '' ?>" style="width: 300px;"><br>
            </p>
            
           
            <input TYPE="submit" NAME="bInsertarAnuncio" VALUE="Publicar Anuncio" class="btn btn-primary"><br>
        </form> 
    </div>

<?php $contenido = ob_get_clean() ?>

<?php include 'layout.php' ?>