<?php ob_start() ?>

    <div class="container text-center p-4">
        <div class="col-md-12" id="cabecera">
            <h1 class="h1Inicio">ANUNCIOS DISPONIBLES</h1>
        </div>
    </div>

    <div class="container py-2">
        <?php if(isset($params['mensaje'])) :?>
            <div class="text-center">
                <b><span style="color: rgba(119, 200, 119, 1);"><?php echo $params['mensaje'] ?></span></b>
            </div>
        <?php endif; ?>

        <div class="row mt-4">
           
                <table class="table table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>Artículo</th>
                            <th>Descripción</th>
                            <th>Precio</th>
                            <th>Vendedor</th>
                            <th>Fecha</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($params['articulos'] as $articulo) : ?>
                            <tr>
                                <td><b><?php echo htmlspecialchars($articulo['titulo']) ?></b></td>
                                <td><?php echo htmlspecialchars($articulo['descripcion']) ?></td>
                                <td><?php echo number_format($articulo['precio'], 2, ',', '.') ?> €</td>
                                <td><?php echo htmlspecialchars($articulo['nombre_usuario']) ?></td>
                                <td><?php echo date('d/m/Y', strtotime($articulo['fecha_publicacion'])) ?></td>
                                <td>
                                    <form method="POST" action="index.php?ctl=actualizarAnuncio">
                                        <input type="hidden" name="id" value="<?php echo $articulo['id']; ?>">
                                        <button type="submit">
                                            Editar
                                        </button>
                                    </form>
                                    <form method="POST" action="index.php?ctl=eliminarAnuncio">
                                        <input type="hidden" name="id" value="<?php echo $articulo['id']; ?>">
                                        <button type="submit">
                                            Eliminar
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            
                
        </div>
        
        <div class="text-center mt-4">
            <a href="index.php?ctl=insertarAnuncio" class="btn btn-success">Publicar nuevo anuncio</a>
        </div>
    </div>

<?php $contenido = ob_get_clean() ?>

<?php include 'layout.php' ?>