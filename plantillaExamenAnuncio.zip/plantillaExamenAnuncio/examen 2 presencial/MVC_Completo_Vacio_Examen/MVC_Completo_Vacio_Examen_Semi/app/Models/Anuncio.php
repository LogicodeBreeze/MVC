<?php

class Anuncio{
      private PDO $conexion;

    public function __construct() {
        $this->conexion = Database::getConnection();
    } 

    public function obtenerAnuncios(){
 
        $query = "SELECT a.*,u.nombre AS nombre_usuario 
            FROM articulos a 
            JOIN usuarios u 
            ON a.usuario_id = u.id";

        return $this->conexion->query($query)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function eliminarAnuncio($id){
        $query= "DELETE FROM articulos WHERE id = :id";

        $consulta = $this->conexion->prepare($query);
        return $consulta->execute([$id]);
    }
    //cargar / obtener anuncio para poder editar 

    //importante!!!! aprender a actualizar 

    public function obtener($id){
        $query= "SELECT * FROM articulos WHERE id = :id"; 

        $consulta=$this->conexion->prepare($query);
        $consulta->bindParam(':id', $id);
        $consulta->execute();
        return $consulta->fetch(); 
    }

     public function actualizarAnuncio($id){
        $query= "UPDATE FROM articulos WHERE id = :id";

        $consulta = $this->conexion->prepare($query);
       
        $consulta->bindParam(':id',$id);

        $consulta->execute();

        return $consulta->fetch();
    }

    public function crearAnuncios($titulo,$descripcion,$precio,$usuario_id){

    //forma de la cabrona (tener en cuenta en examen)
        // $query= "INSERT INTO articulos (titulo, descripcion, precio, usuario_id 
        //     VALUES (:titulo, :descripcion, :precio, :usuario_id)";
       
        // $insertar = $this->conexion->prepare($query);

        // $insertar->bindParam(':titulo', $titulo);

        // $insertar->bindParam(':descripcion', $descripcion);

        // $insertar->bindParam(':precio', $precio);

        // $insertar->bindParam(':usuario_id', $usuario_id);
        
        //return (int)$this->conexion->lastInsertId(); 

        //la forma de DANI facil 
     $query= "INSERT INTO articulos (titulo, descripcion, precio, usuario_id) VALUES (?,?,?,?)";

     $insertar=$this->conexion->prepare($query);

     return $insertar->execute([$titulo,$descripcion,$precio,$usuario_id]);

    }

    
}
?>