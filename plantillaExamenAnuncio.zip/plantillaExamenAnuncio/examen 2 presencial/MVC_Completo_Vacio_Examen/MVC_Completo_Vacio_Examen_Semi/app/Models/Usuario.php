<?php

class Usuario{
      private PDO $conexion;

    public function __construct() {
        $this->conexion = Database::getConnection();
    } 

    public function iniciarSesion($nombre){

    /*
    Guarda en $query una consulta SQL.

SELECT * significa “trae todas las columnas”.

FROM usuarios indica la tabla.

WHERE nombre = ? filtra por el campo nombre.

El ? es un placeholder (marcador) para usar una consulta preparada y evitar inyección SQL 

$this->conexion es tu conexión PDO guardada en la clase.

prepare($query) prepara la consulta SQL (no la ejecuta todavía).

Devuelve un objeto tipo PDOStatement, que guardas en $consulta.

Ejecuta la consulta preparada.

Le pasas un array con los valores que reemplazarán los ?.

En este caso, el primer ? se reemplaza por $nombre.

PDO se encarga de escapar el valor correctamente, por eso es más seguro.

*/


        $query = "SELECT * FROM usuarios WHERE nombre = ?";

        $consulta = $this->conexion->prepare($query);
        
        $consulta->execute([$nombre]);

        return $consulta->fetch(PDO::FETCH_ASSOC);
    }
 
}
?>